package com.example.library_automation;

public @interface OnClick {
}
