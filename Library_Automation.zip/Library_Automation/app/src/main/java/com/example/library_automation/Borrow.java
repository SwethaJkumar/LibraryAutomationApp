package com.example.library_automation;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Borrow extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrow);
    }
   /*public void borrow_books()
    {



        mdatabase= FirebaseDatabase.getInstance().getReference();
        DatabaseReference child=mdatabase.child("BorrowedBooks");
        DatabaseReference UserDB=child.child(user.getUid()).child("Book").child(id);

       // Calendar c = Calendar.getInstance();
        SimpleDateFormat df1 = new SimpleDateFormat("dd-MMM-yyyy");
        String formattedDate1 = df1.format(c.getTime());
        Calendar c2 = Calendar.getInstance();
        c2.add(Calendar.MONTH, 1);
        String retur=df1.format(c2.getTime());
        Calendar c3 = Calendar.getInstance();
        c3.add(Calendar.DATE, 27);
        String notify=df1.format(c3.getTime());




        UserDB.child("Book_ID").setValue(id);
        UserDB.child("Book_Name").setValue(name);
        UserDB.child("Book_Category").setValue(cate);
        UserDB.child("Book_Location").setValue(locate);
        //UserDB.child("Status").setValue("OUT");
        UserDB.child("Borrowed_Date").setValue(formattedDate1);
        UserDB.child("Return_Date").setValue(retur);
        UserDB.child("Notify_Date").setValue(notify);
        UserDB.child("User").setValue(user.getUid());

        DatabaseReference child1=mdatabase.child("Adminlist");
        DatabaseReference UserDB1=child1.child(id);
        UserDB1.child("Book_ID").setValue(id);
        UserDB1.child("Book_Name").setValue(name);
        UserDB1.child("Book_Category").setValue(cate);
        UserDB1.child("Book_Location").setValue(locate);
        UserDB1.child("Borrowed_Date").setValue(formattedDate1);
        UserDB1.child("Return_Date").setValue(retur);
        UserDB1.child("Notify_Date").setValue(notify);
        UserDB1.child("User").setValue(user.getUid());


        update_books();
        Toast.makeText(getApplicationContext(),"Book added successful",Toast.LENGTH_SHORT).show();
        bookname.setText("");




    }*/
}